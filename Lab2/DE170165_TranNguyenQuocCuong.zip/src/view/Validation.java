package view;

public class Validation {
	public Validation() {
		
	}
	public String scorePattern = "^(10|\\d)(\\.\\d+)?$";
}
