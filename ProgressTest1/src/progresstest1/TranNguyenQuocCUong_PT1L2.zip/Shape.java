/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package progresstest1;

/**
 *
 * @author Administrator
 */
public interface Shape {
    public float Area();
    public float Circumference();
}
