/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progresstest1;


/**
 *
 * @author Administrator
 */
public class TestCircle {
    public static void main(String[] args) {
        Point a = new Point(1, 2);    
        Point b = new Point(3, 4);
        System.out.println("The distance between A(1,2) and B(3,4) is: " + Point.getDistance(1, 2, 3, 4));
        Circle c = new Circle(1, 2, 5);
        Circle d = new Circle(3, 4, 6);
        if(Circle.checkContact(1,3,2,4,5,6)){
            System.out.println("Two circle are outer contact");
        }
        else {
            System.out.println("Two circle are not outer contact");
        }
}
}