/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progresstest1;

/**
 *
 * @author Administrator
 */
public class Circle extends Point implements Shape{
    
    private float r;

    public Circle() {
    }

    public Circle(float x, float y, float r) {
        super(x, y);
    }

    public float getR() {
        return r;
    }

    public void setR(float r) {
        this.r = r;
    }
    
    public static boolean checkContact(float x1, float x2, float y1, float y2, float r1, float r2){
        if (getDistance(x1, x2, y1, y2) == (r1 + r2)){
            return true;
        }
        else {
            return false;
        }
    }

    @Override
    public float Area() {
        return (float) (2*r*3.14);
    }

    @Override
    public float Circumference() {
        return (float) (r*r*3.14);
    }
    
    
}
