package view;

import java.util.Scanner;

public abstract class Menu {

    public static int getChoice(Object[] options) {
        System.out.println("---------------");
        System.out.println("Menu: ");
        for (int i = 0; i < options.length; i++) {
            System.out.println((i + 1) + ". " + options[i]);
        }
        System.out.println("---------------");
        System.out.println("Enter your choice: ");
        Scanner sc = new Scanner(System.in);
        return Integer.parseInt(sc.nextLine());
    }
}
